export const MENU = [
  {
    id: 1,
    name: "Pizza Margherita",
    description: "Molho de tomate, mussarela, manjericão fresco.",
    price: 48.90
  },
  {
    id: 2,
    name: "Lasanha à Bolonhesa",
    description: "Lasanha recheada com carne moída, molho e queijo.",
    price: 54.90
  },
  {
    id: 3,
    name: "Hambúrguer Artesanal",
    description: "Pão brioche, hambúrguer 180g, queijo, salada e molho especial.",
    price: 32.00
  }
];