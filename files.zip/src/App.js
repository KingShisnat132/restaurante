import React, { useState } from "react";
import { MENU } from "./menu";
import "./App.css";

function formatCurrency(value) {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (item) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) =>
          i.id === item.id ? { ...i, qty: i.qty + 1 } : i
        );
      }
      return [...prev, { ...item, qty: 1 }];
    });
  };

  const removeFromCart = (id) => {
    setCart((prev) => prev.filter((i) => i.id !== id));
  };

  const updateQty = (id, qty) => {
    if (qty <= 0) removeFromCart(id);
    else setCart((prev) => prev.map((i) => (i.id === id ? { ...i, qty } : i)));
  };

  const getTotal = () =>
    cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const getWhatsappMessage = () => {
    if (cart.length === 0) return "Olá, gostaria de fazer um pedido!";
    let msg = "Olá, gostaria de fazer um pedido:\n";
    cart.forEach((item) => {
      msg += `- ${item.name} (x${item.qty}): ${formatCurrency(item.price * item.qty)}\n`;
    });
    msg += `Total: ${formatCurrency(getTotal())}`;
    return encodeURIComponent(msg);
  };

  const whatsappNumber = "5511999999999"; // coloque o número do restaurante (com DDD e sem sinais)

  return (
    <div className="container">
      <h1>Restaurante Sabor & Arte</h1>
      <h2>Cardápio</h2>
      <div className="menu">
        {MENU.map((item) => (
          <div className="menuItem" key={item.id}>
            <h3>{item.name}</h3>
            <p>{item.description}</p>
            <b>{formatCurrency(item.price)}</b>
            <button onClick={() => addToCart(item)}>Adicionar</button>
          </div>
        ))}
      </div>
      <h2>Carrinho</h2>
      {cart.length === 0 && <p>Seu carrinho está vazio.</p>}
      {cart.length > 0 && (
        <div className="cart">
          {cart.map((item) => (
            <div className="cartItem" key={item.id}>
              <span>{item.name}</span>
              <input
                type="number"
                min="1"
                value={item.qty}
                onChange={(e) => updateQty(item.id, parseInt(e.target.value, 10))}
              />
              <span>{formatCurrency(item.price * item.qty)}</span>
              <button onClick={() => removeFromCart(item.id)}>Remover</button>
            </div>
          ))}
          <b>Total: {formatCurrency(getTotal())}</b>
          <a
            className="whatsappButton"
            href={`https://wa.me/${whatsappNumber}?text=${getWhatsappMessage()}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            Enviar pedido pelo WhatsApp
          </a>
        </div>
      )}
      <footer>
        <small>&copy; {new Date().getFullYear()} Restaurante Sabor & Arte</small>
      </footer>
    </div>
  );
}

export default App;